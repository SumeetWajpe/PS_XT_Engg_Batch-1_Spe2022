var express = require("express");
var router = express.Router();

/* GET home page. */
router.get("/", function (req, res, next) {
  res.render("index", { title: "Express" });
});
// router.get("/products", function (req, res, next) {
//   let products = [
//     { name: "LED TV", price: 50000 },
//     { name: "Mac Book Pro", price: 250000 },
//   ];

//   res.render("products", { products });
// });

module.exports = router;

// products - array -> {name,price} -> 5 items
