const binaryOp = {
  sum: function (a, b) {
    return a + b;
  },
  subtract: function sum(a, b) {
    return a - b;
  },
  divide: function sum(a, b) {
    return a / b;
  },
  product: function (a, b) {
    return a * b;
  },
};

module.exports = binaryOp;
