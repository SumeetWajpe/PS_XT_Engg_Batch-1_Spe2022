import "./App.css";
import "bootstrap/dist/css/bootstrap.css";
import React from "react";
import User from "./user";

export default class App extends React.Component {
  users = [
    {
      name: "Romit",
      age: 20,
      avatarUrl: "https://avatars.githubusercontent.com/u/1?v=4",
    },
    {
      name: "Shobhit",
      age: 25,
      avatarUrl: "https://avatars.githubusercontent.com/u/2?v=4",
    },
    {
      name: "Romit",
      age: 20,
      avatarUrl: "https://avatars.githubusercontent.com/u/1?v=4",
    },
    {
      name: "Shobhit",
      age: 25,
      avatarUrl: "https://avatars.githubusercontent.com/u/2?v=4",
    },
    {
      name: "Romit",
      age: 20,
      avatarUrl: "https://avatars.githubusercontent.com/u/1?v=4",
    },
    {
      name: "Shobhit",
      age: 25,
      avatarUrl: "https://avatars.githubusercontent.com/u/2?v=4",
    },
    {
      name: "Romit",
      age: 20,
      avatarUrl: "https://avatars.githubusercontent.com/u/1?v=4",
    },
    {
      name: "Shobhit",
      age: 25,
      avatarUrl: "https://avatars.githubusercontent.com/u/2?v=4",
    },
    {
      name: "Romit",
      age: 20,
      avatarUrl: "https://avatars.githubusercontent.com/u/1?v=4",
    },
    {
      name: "Shobhit",
      age: 25,
      avatarUrl: "https://avatars.githubusercontent.com/u/2?v=4",
    },
  ];

  render() {
    let allUsers = this.users.map(user => <User userdetails={user} />);
    return (
      <div className="container">
        {/* <User userdetails={this.firstUser} />
        <User userdetails={this.secondUser} /> */}

        {/* <User name="Amit" age="25" />
        <User name="Shobhit" age="28" /> */}

        {/* [<User userdetails={user} />,<User userdetails={user} />] */}

        <div className="row">{allUsers}</div>
      </div>
    );
  }
}
