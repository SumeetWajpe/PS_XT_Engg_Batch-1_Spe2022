import React from "react";
import "./user.styles.css"
class User extends React.Component {
  render() {
    return <div className="col-md-3">
        <div className="userthumbnail">
        <img src={this.props.userdetails.avatarUrl} alt={this.props.userdetails.name} height="200px" width="260px" />
        
        <div className="row justify-content-between align-items-center">
            <div className="col"><h2>{this.props.userdetails.name}</h2></div>
            <div className="col"></div>
            <div className="col"> <strong>{this.props.userdetails.age} yrs</strong></div>
        </div>
        
         <button className="btn btn-primary">Subscribe</button>
    </div>
    </div>;
  }
}

export default User;