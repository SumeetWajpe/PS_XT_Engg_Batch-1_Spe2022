import React from "react";
import Header from "../Header/header";
import User from "../user/user";
export class UserList extends React.Component {
  constructor() {
    super();
    this.state = {
      users: [],
    };
  }

  componentDidMount() {
    fetch("http://localhost:4000/users")
      .then(res => res.json())
      .then(users => this.setState({ users }));
  }
  deleteUser(userId) {
    console.log(`Deleting User with id : ${userId}`);
    let newUsers = this.state.users.filter(u => u.id != userId);
    this.setState({ users: newUsers });
  }

  render() {
    console.log("Render : UserList !");
    let allUsers = this.state.users.map(user => (
      <User
        userdetails={user}
        key={user.id}
        deleteUser={id => this.deleteUser(id)}
      />
    ));
    return (
      <div >
        <Header>
          <h1>List of Users</h1>
        </Header>
        <div className="row">{allUsers}</div>
      </div>
    );
  }
}
