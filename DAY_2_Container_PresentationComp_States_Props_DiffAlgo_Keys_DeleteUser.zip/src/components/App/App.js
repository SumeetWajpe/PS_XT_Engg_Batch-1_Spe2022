import "./App.css";
import "bootstrap/dist/css/bootstrap.css";
import React from "react";
import { UserList } from "../userlist/userslist";
import Posts from "../posts/posts";

export default class App extends React.Component {
  render() {
    return (
      <div className="container">
        {/* <UserList /> */}
        <Posts />
      </div>
    );

    // return <Posts />;
  }
}
