import React from "react";
import "./user.styles.css";

// import { MdSubscriptions } from "react-icons/md";
import { FaUsers } from "react-icons/fa";
import { BsFillTrashFill } from "react-icons/bs";
import { IoMdStar } from "react-icons/io";

class User extends React.Component {
  constructor(props) {
    super(props);
    this.state = { currSubscribers: this.props.userdetails.subscribers };
  }
  addSubscribers() {
    console.log("Adding subscribers");
    //console.log( this.props.userdetails.subscribers++);// props are readonly
    // console.log(this)
    // this.state.currSubscribers++; // state is immutable
    this.setState({ currSubscribers: this.state.currSubscribers + 1 });
  }

  render() {
    // console.log("Render : User !");
    let ratings = [];
    for (let i = 0; i < this.props.userdetails.rating; i++) {
      ratings.push(<IoMdStar key={"star-" + i} size="25" color="orange" />);
    }
    return (
      <div className="col-md-3">
        <div className="userthumbnail">
          <img
            src={this.props.userdetails.avatarUrl}
            alt={this.props.userdetails.name}
            className="img-fluid"
          />

          <div className="row justify-content-between align-items-center">
            <div className="col">
              <h4>{this.props.userdetails.name}</h4>
            </div>
            <div className="col"></div>
            <div className="col">
              {" "}
              <span>{this.props.userdetails.age} yrs</span>
            </div>
          </div>

          <div>{ratings}</div>
          <button
            className="btn btn-primary my-2"
            onClick={() => this.addSubscribers()}
          >
            {" "}
            <FaUsers /> {this.state.currSubscribers}
          </button>

          <button
            className="btn btn-danger mx-2 my-2"
            onClick={() => this.props.deleteUser(this.props.userdetails.id)}
          >
            <BsFillTrashFill />
          </button>
        </div>
      </div>
    );
  }
}

export default User;
