import React, { Component } from "react";
import Header from "../Header/header";

export default class Posts extends Component {
  state = { posts: [] };
  componentDidMount() {
    // DOM is ready !
    // AJAX | integrating with other library
    fetch("https://jsonplaceholder.typicode.com/posts")
      .then(res => res.json())
      .then(posts => this.setState({ posts }));
  }
  render() {
    let postsToBeCreated = this.state.posts.map(p => (
      <li className="list-group-item" key={p.id}>
        {p.title}
      </li>
    ));
    return (
      <div>
        <Header>
          <h1>All Posts</h1>
        </Header>
        <ul className="list-group">{postsToBeCreated}</ul>
      </div>
    );
  }
}
