function Permanent() {
  this.salary = 100000;
}

function Contractor() {
  this.salary = 200000;
}

function Freelancer() {
  this.hourlyCharges = 5000;
}

export function createEmployeeFactory(type) {
  let emp;
  switch (type) {
    case "Permanent":
      return new Permanent();
    case "Contractor":
      return new Contractor();
    case "Freelancer":
      return new Freelancer();

    default:
      console.log("Employee type does not exist !");
      break;
  }
}
